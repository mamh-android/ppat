swdl=`ps -ef | grep swdl_linux | grep -v grep | awk -F" " '{print $2 }'`
if [ "$swdl" != "" ]
then
    echo "$swdl"
fi
