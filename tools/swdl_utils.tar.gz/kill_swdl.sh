swdl=$1
if [ "$swdl" != "" ]
then
    echo "kill current running swdl pid $swdl"
    sudo kill $swdl
fi
